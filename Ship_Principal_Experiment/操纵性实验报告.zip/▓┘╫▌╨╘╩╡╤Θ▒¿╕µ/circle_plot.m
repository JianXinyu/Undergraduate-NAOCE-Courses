clear all;
close all;
clc;

LID = fopen('turning circle L35');
RID = fopen('turning circle R35');
L = textscan(LID,'%f %f %f %f');
R = textscan(RID,'%f %f %f %f');
figure(1);
set(gcf,'color','white');
plot(L{1,1}(:,1),L{1,2}(:,1),'b');
hold on;
plot(L{1,3}(:,1),L{1,4}(:,1),'r');
legend('���Ĺ켣','���׹켣');
xlabel('X','FontWeight','bold');
ylabel('Y','FontWeight','bold');
title('Left Turning Circle(35^��)');
saveas(gcf,'Left_Turing_Circle.jpg')
figure(2);
set(gcf,'color','white');
plot(R{1,1}(:,1),R{1,2}(:,1),'b');
hold on;
plot(R{1,3}(:,1),R{1,4}(:,1),'r');
legend('���Ĺ켣','���׹켣');
xlabel('X','FontWeight','bold');
ylabel('Y','FontWeight','bold');
title('Right Turning Circle(35^��)');
saveas(gcf,'Right_Turning_Circle.jpg');

% L_Length = length(L{1,1}(:,1));
% R_Length = length(R{1,1}(:,1));
